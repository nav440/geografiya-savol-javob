import os
import logging
from telegram import Update
from telegram.ext import Application, CommandHandler, MessageHandler, filters, ContextTypes
import anthropic

# Logging sozlamalari
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# Claude client sozlamalari
client = anthropic.Anthropic(api_key=os.getenv("ANTHROPIC_API_KEY"))

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Bot start qilganda salom beradi"""
    user_name = update.effective_user.first_name
    welcome_text = f"""Salom {user_name}! 👋

Men geografiya bot-man. Geografiya haqida har qanday savolga javob bera olaman:
- Davlatlar va shaharlari haqida
- Geografik ob'ektlar (tog', daryo, ko'l) haqida
- Iqlim va tabiiy resurslar haqida
- Aholisi va iqtisodiyoti haqida
- Va boshqa geografiya masalalari haqida

Savolni yozib yuboring va men javob berayman! 📍"""
    
    await update.message.reply_text(welcome_text)

async def handle_geography_question(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Geografiya savollariga javob beradi"""
    user_question = update.message.text
    
    # Javob berilayotgani haqida xabar
    loading_msg = await update.message.reply_text("Javob qaralmoqda... ⏳")
    
    try:
        # Claude API ga savolni jo'natadi
        message = client.messages.create(
            model="claude-opus-4-1",
            max_tokens=1024,
            messages=[
                {
                    "role": "user",
                    "content": f"""Siz geografiya ekspertidasiz. Quyidagi geografiya savolga aniq va to'liq javob bering. 
                    
Savolni O'zbekcha javob bering va javobni tuzilgan qilib bering:

{user_question}"""
                }
            ]
        )
        
        # Javob olish
        answer = message.content[0].text
        
        # Javobni 4096 ta belgiga bo'lsa, bir nechta xabarlarga ajratish
        if len(answer) > 4096:
            for i in range(0, len(answer), 4096):
                await update.message.reply_text(answer[i:i+4096])
        else:
            await update.message.reply_text(answer)
        
        # Yuklash xabarini o'chirib tashlash
        await loading_msg.delete()
        
    except anthropic.APIError as e:
        await loading_msg.delete()
        error_text = f"❌ Xatolik: {str(e)}\n\nAnthropic API key ni tekshiring."
        await update.message.reply_text(error_text)
        logger.error(f"API Error: {e}")
    except Exception as e:
        await loading_msg.delete()
        await update.message.reply_text(f"❌ Noma'lum xatolik: {str(e)}")
        logger.error(f"Error: {e}")

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Yordam komasndasini ko'rsatadi"""
    help_text = """📚 Bot buyruqlari:
/start - Botni start qilish
/help - Yordam ko'rsatadi
/about - Bot haqida ma'lumot

💡 Misol savollar:
- Britaniya qaysi davlatda joylashgan?
- Nil daryosi qaysi davlatlardan o'tadi?
- Sahro cho'lining maydoni necha milyon km2?
- Afrikaning eng baland tog'i qaysi?
"""
    await update.message.reply_text(help_text)

async def about_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Bot haqida ma'lumot"""
    about_text = """🌍 Geografiya Bot haqida

Bu bot antropichning Claude AI modeli asosida yaratilgan.
Geografiya masalalarida yuqori aniqlik bilan javob beradigan AI-powered bot.

Ishlatilgan texnologiyalar:
- python-telegram-bot
- Anthropic Claude API
- Python 3.8+

Muallif: AI Assistant
Versiya: 1.0"""
    await update.message.reply_text(about_text)

def main():
    """Bot-ni ishga tushiradi"""
    # Telegram token
    TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
    
    if not TOKEN:
        print("❌ Xatolik: TELEGRAM_BOT_TOKEN o'rnatilmagan!")
        print("Iltimos, .env faylida TOKEN ni o'rnating")
        return
    
    if not os.getenv("ANTHROPIC_API_KEY"):
        print("❌ Xatolik: ANTHROPIC_API_KEY o'rnatilmagan!")
        print("Iltimos, .env faylida API KEY ni o'rnating")
        return
    
    # Application yaratish
    application = Application.builder().token(TOKEN).build()
    
    # Buyruq handlerlari
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("help", help_command))
    application.add_handler(CommandHandler("about", about_command))
    
    # Text xabar handleri
    application.add_handler(MessageHandler(
        filters.TEXT & ~filters.COMMAND,
        handle_geography_question
    ))
    
    print("✅ Bot ishga tushdi. Ctrl+C bilan to'xtatish uchun bosing...")
    
    # Bot-ni ishga tushirish
    application.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == "__main__":
    main()
