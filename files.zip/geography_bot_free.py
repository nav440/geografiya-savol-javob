import os
import logging
import httpx
from telegram import Update
from telegram.ext import Application, CommandHandler, MessageHandler, filters, ContextTypes

# Logging sozlamalari
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Bot start qilganda salom beradi"""
    user_name = update.effective_user.first_name
    welcome_text = f"""Salom {user_name}! 👋

Men geografiya bot-man. Geografiya haqida har qanday savolga javob bera olaman:
- Davlatlar va shaharlari haqida
- Geografik ob'ektlar (tog', daryo, ko'l) haqida
- Iqlim va tabiiy resurslar haqida
- Aholisi va iqtisodiyoti haqida
- Va boshqa geografiya masalalari haqida

Savolni yozib yuboring va men javob berayman! 📍"""
    
    await update.message.reply_text(welcome_text)

async def search_wikipedia(query: str) -> str:
    """Wikipedia'dan ma'lumot qidiradi"""
    try:
        async with httpx.AsyncClient(timeout=10) as client:
            # Wikipedia API ga so'rov
            params = {
                'action': 'query',
                'format': 'json',
                'srsearch': query,
                'srwhat': 'text',
                'srlimit': 1,
                'list': 'search'
            }
            
            response = await client.get(
                'https://en.wikipedia.org/w/api.php',
                params=params
            )
            response.raise_for_status()
            data = response.json()
            
            if data['query']['search']:
                title = data['query']['search'][0]['title']
                snippet = data['query']['search'][0]['snippet']
                
                # HTML taglarni olib tashlash
                snippet = snippet.replace('<span class="searchmatch">', '')
                snippet = snippet.replace('</span>', '')
                
                return f"""📍 *{title}*\n\n{snippet}...\n\n_Wikipedia orqali topildi_"""
            else:
                return "❌ Hech qanday natija topilmadi. Boshqa so'rovni sinab ko'ring."
                
    except httpx.TimeoutException:
        return "⏱️ So'rov vaqti tugadi. Iltimos, qayta urinib ko'ring."
    except Exception as e:
        logger.error(f"Wikipedia API error: {e}")
        return f"❌ Xatolik: {str(e)}"

async def handle_geography_question(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Geografiya savollariga javob beradi"""
    user_question = update.message.text
    
    # Javob berilayotgani haqida xabar
    loading_msg = await update.message.reply_text("Javob qidirilmoqda... ⏳")
    
    try:
        # Wikipedia'da qidirish
        answer = await search_wikipedia(user_question)
        
        # Javobni jo'natish
        await update.message.reply_text(answer, parse_mode="Markdown")
        
        # Yuklash xabarini o'chirib tashlash
        await loading_msg.delete()
        
    except Exception as e:
        await loading_msg.delete()
        await update.message.reply_text(f"❌ Xatolik: {str(e)}")
        logger.error(f"Error: {e}")

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Yordam komasndasini ko'rsatadi"""
    help_text = """📚 Bot buyruqlari:
/start - Botni start qilish
/help - Yordam ko'rsatadi
/about - Bot haqida ma'lumot

💡 Misol savollar:
- Britaniya
- Nil daryosi
- Sahro cho'li
- Afrikaning eng baland tog'i
"""
    await update.message.reply_text(help_text)

async def about_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Bot haqida ma'lumot"""
    about_text = """🌍 Geografiya Bot haqida

Bu bot Wikipedia API asosida yaratilgan bepul bot.
Geografiya masalalarida tez va aniq javob beradigan bot.

Ishlatilgan texnologiyalar:
- python-telegram-bot
- Wikipedia API
- Python 3.8+

Muallif: AI Assistant
Versiya: 1.0 (Free)"""
    await update.message.reply_text(about_text)

def main():
    """Bot-ni ishga tushiradi"""
    # Telegram token
    TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
    
    if not TOKEN:
        print("❌ Xatolik: TELEGRAM_BOT_TOKEN o'rnatilmagan!")
        print("Iltimos, .env faylida TOKEN ni o'rnating")
        return
    
    # Application yaratish
    application = Application.builder().token(TOKEN).build()
    
    # Buyruq handlerlari
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("help", help_command))
    application.add_handler(CommandHandler("about", about_command))
    
    # Text xabar handleri
    application.add_handler(MessageHandler(
        filters.TEXT & ~filters.COMMAND,
        handle_geography_question
    ))
    
    print("✅ Bot ishga tushdi. Ctrl+C bilan to'xtatish uchun bosing...")
    print("📌 Bu versiya Wikipedia API'ni ishlatadi (Bepul)")
    
    # Bot-ni ishga tushirish
    application.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == "__main__":
    main()
