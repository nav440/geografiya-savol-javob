# 🚀 Tezkor Start - Geografiya Bot

## 5 Daqiqada Bot Ishga Tushirish

### 1️⃣ TOKEN'larni Olish (2 daqiqa)

**Telegram Token:**
- Telegram'da `@BotFather` ni toping
- `/newbot` yuboring
- Bot nomi va username kiriting
- Token'ni saqlang

**YOKI Bepul variantdan foydalaning** (Token faqat kerak):
```
Faqat TELEGRAM_BOT_TOKEN kerak!
ANTHROPIC_API_KEY kerak emas!
```

### 2️⃣ Setup (1 daqiqa)

```bash
# Papkaga o'tish
cd /home/claude

# Kutubxonalarni o'rnatish
pip install python-telegram-bot httpx

# .env fayl yaratish
cat > .env << EOF
TELEGRAM_BOT_TOKEN=YOUR_TOKEN_HERE
EOF
```

### 3️⃣ Bot'ni Ishga Tushirish (1 daqiqa)

```bash
# BEPUL VARIANT (Wikipedia):
python geography_bot_free.py

# YA PREMIUM VARIANT (Claude AI):
# Avval ANTHROPIC_API_KEY ni .env ga qo'shing
python geography_bot.py
```

### 4️⃣ Telegram'da Test Qilish

Bot @username'ni toping va:
- `/start` yuboring
- "Britaniya qayda?" yuboring
- Javobni oling! ✅

---

## 📊 Ikki Variant Taqqoslash

| Feature | Free (Wikipedia) | Premium (Claude) |
|---------|------------------|-----------------|
| **Narxi** | Bepul ✅ | API key kerak 💰 |
| **Aniqlik** | Yaxshi | Juda yaxshi |
| **Tezlik** | Tez | O'rtacha |
| **Javob Turi** | Wikipedia matn | AI javob |
| **Setup** | 5 daqiqa | 10 daqiqa |

---

## ⚡ Faqat Kerakli Fayllar

### Variant 1: BEPUL (Wikipedia)
```
geography_bot_free.py
requirements.txt
.env
```

### Variant 2: PREMIUM (Claude)
```
geography_bot.py
requirements.txt
.env
```

---

## 🔧 requirements.txt

```
python-telegram-bot==20.7
httpx==0.24.1  # Bepul variant uchun
anthropic==0.25.0  # Premium variant uchun
```

---

## 💡 Misol SO'ROVLAR

```
"Nil daryosi qaysi davlatda?"
"Everest tog'ining balandligi?"
"O'zbekistan aholisi?"
"Qo'ng'iroq ko'lining suvi sho'r mi?"
"Paris qaysi davlatda?"
"Samarqand tarixi?"
```

---

## ✅ Tekshiruv Ro'yxati

- [ ] Telegram token oldin
- [ ] .env fayl yaratildi
- [ ] Python o'rnatildi
- [ ] Kutubxonalar o'rnatildi
- [ ] Bot ishga tushti
- [ ] /start buyrug'i ishladi
- [ ] Savol bergan javob oldin

---

## 🎯 Keyingi Qadamlar

1. **Customize qilish** - Bot nomini, tavsifini o'zgartiring
2. **Deploy** - Heroku yoki Render.com'da joylashtiring
3. **Feature qo'shish** - Ro'yxat, reyting, statistika qo'shing
4. **Admin panel** - Admin buyruqlari qo'shing

---

## 🆘 Xatoliklar

### "Token xato"
```bash
@BotFather'ga /mybot yuboring tokenni ko'ring
```

### "Bot javob bermayapti"
```bash
# Logs ni ko'ring
# .env ni tekshiring
# Internet ulanishini tekshiring
```

### "ModuleNotFoundError"
```bash
pip install --upgrade python-telegram-bot
```

---

**Shuni yoddingiz: Bepul variant hamma uchun yetarli! 🎉**
