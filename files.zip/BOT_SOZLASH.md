# 🌍 Geografiya Telegram Bot - Sozlash Yo'riqnomasi

## 1. Zarur Narsalarni Tayyorlash

### A) Telegram Bot Token Olish
1. Telegram'da `@BotFather` ga yozib yuborish
2. `/newbot` buyrug'ini yuboring
3. Bot nomi va username'ni kiriting
4. Token'ni oling va saqlang

### B) Anthropic API Key Olish
1. https://console.anthropic.com ga o'tish
2. Akkaunt yaratish yoki login qilish
3. API Keys bo'limiga o'tish
4. Yangi key yaratish va saqlash

## 2. Python Kutubxonalarini O'rnatish

```bash
pip install -r requirements.txt
```

Yoki alohida:
```bash
pip install python-telegram-bot==20.7 anthropic==0.25.0 python-dotenv==1.0.0
```

## 3. .env Faylini Yaratish

Proyekt papkasida `.env` fayl yarating va quyidagini yozing:

```
TELEGRAM_BOT_TOKEN=YOUR_TELEGRAM_TOKEN_HERE
ANTHROPIC_API_KEY=YOUR_ANTHROPIC_API_KEY_HERE
```

Misol:
```
TELEGRAM_BOT_TOKEN=123456789:ABCdefGHIjklmnopQRStuvWXYZ
ANTHROPIC_API_KEY=sk-ant-v4-abcdef123456...
```

## 4. Bot-ni Ishga Tushirish

```bash
python geography_bot.py
```

Agar muvaffaqiyatli bo'lsa, konsolda quyidagi xabar ko'rinadi:
```
✅ Bot ishga tushdi. Ctrl+C bilan to'xtatish uchun bosing...
```

## 5. Bot Bilan Ishlash

### Bot Buyruqlari:
- `/start` - Botni boshlash
- `/help` - Yordam ko'rsatish
- `/about` - Bot haqida

### Savollar:
Shunchaki geografiya savolni yozib yuboring:
- "Moskva qaysi davlatning poytaxtidir?"
- "Himalay tog' zanjourining balandligi necha km?"
- "O'zbekistan bilan qaysi davlatlar chegaradashan?"

## 6. Muammolarni Hal Qilish

### Xatolik: "No module named 'telegram'"
**Yechim:** `pip install python-telegram-bot` buyrug'ini qayta bajaring

### Xatolik: "TELEGRAM_BOT_TOKEN o'rnatilmagan"
**Yechim:** `.env` fayl mavjudligini va TOKEN correctligini tekshiring

### Xatolik: "ANTHROPIC_API_KEY o'rnatilmagan"
**Yechim:** `.env` faylida Anthropic API key ni tekshiring

### Bot javob bermayapti
**Yechim:** 
- API key'ni tekshiring
- Internet ulanishi mavjud ekanligini tekshiring
- Telegram token'ni tekshiring

## 7. Deploylash (Server'da Ishga Tushirish)

Agar server'da (masalan, Heroku, Render.com) ishga tushirmoqchi bo'lsangiz:

### 1. requirements.txt faylini yarating:
```
python-telegram-bot==20.7
anthropic==0.25.0
python-dotenv==1.0.0
```

### 2. Environment variables'ni server'da o'rnating:
- `TELEGRAM_BOT_TOKEN`
- `ANTHROPIC_API_KEY`

### 3. Start script'i yarating (Procfile):
```
worker: python geography_bot.py
```

## 8. Bot Features'lari

✅ O'zbekcha interfeys  
✅ Geografiya savollariga AI javob  
✅ Uzun javoblarni avtomatik bo'lish  
✅ Error handling va logging  
✅ Tez va aniq javoblar  
✅ 24/7 faollik (server'da)

## 9. Customize Qilish

### Bot nomi o'zgartirish:
`@BotFather` ga `/setname` buyrug'ini yuboring

### Bot tavsifi o'zgartirish:
`@BotFather` ga `/setdescription` buyrug'ini yuboring

### Savollarni custom prompt'lashtirish:
`handle_geography_question` funksiyasida prompt'ni o'zgartiring

## 🆘 Yordam

Bot haqida savollar uchun javobni ko'rib chiqing yoki kod'ni test qiling.

Omad! 🚀
